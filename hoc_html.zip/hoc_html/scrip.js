function scrollToServices() {
    const section = document.getElementById('services');
    section.scrollIntoView({ behavior: 'smooth' });
  }
  
  const modal = document.getElementById('serviceModal');
  const modalBody = document.getElementById('modalBody');
  const closeBtn = document.querySelector('.close-btn');
  
  const serviceDetails = {
    skincare: `
      <h2>Chăm sóc da chuyên sâu</h2>
      <p>Liệu trình chăm sóc da bao gồm tẩy tế bào chết, xông hơi, hút mụn, massage, đắp mặt nạ và dưỡng ẩm sâu giúp da sáng khỏe và mịn màng.</p>
      <ul>
        <li>Liệu trình da mụn, da dầu, da khô</li>
        <li>Sử dụng sản phẩm cao cấp</li>
        <li>Chuyên viên giàu kinh nghiệm</li>
      </ul>
    `,
    makeup: `
      <h2>Trang điểm chuyên nghiệp</h2>
      <p>Dịch vụ makeup dành cho tiệc cưới, sự kiện, chụp ảnh hoặc trang điểm nhẹ hàng ngày.</p>
      <ul>
        <li>Makeup cô dâu - Makeup dự tiệc</li>
        <li>Chọn tông trang điểm phù hợp</li>
        <li>Sử dụng mỹ phẩm chính hãng</li>
      </ul>
    `,
    nails: `
      <h2>Làm móng nghệ thuật</h2>
      <p>Chăm sóc và thiết kế móng tay, móng chân với nhiều kiểu dáng, màu sắc, phong cách hiện đại.</p>
      <ul>
        <li>Sơn gel, đắp bột, vẽ móng</li>
        <li>Khử khuẩn dụng cụ kỹ lưỡng</li>
        <li>Không gian thư giãn nhẹ nhàng</li>
      </ul>
    `
  };
  
  document.querySelectorAll('.detail-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.getAttribute('data-service');
      modalBody.innerHTML = serviceDetails[type];
      modal.style.display = 'flex';
    });
  });
  
  closeBtn.onclick = () => {
    modal.style.display = 'none';
  };
  
  window.onclick = (event) => {
    if (event.target === modal) {
      modal.style.display = 'none';
    }
  };
  



  function openLogin() {
    document.getElementById("loginModal").style.display = "flex";
  }
  
  function closeLogin() {
    document.getElementById("loginModal").style.display = "none";
  }
  
  window.onclick = function(event) {
    const modal = document.getElementById("loginModal");
    if (event.target === modal) {
      modal.style.display = "none";
    }
  }
  